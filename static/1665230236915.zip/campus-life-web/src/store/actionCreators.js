import { MENU_TOGGLE } from './actionType'

export const menuToggleAction = () => ({
    type: MENU_TOGGLE
})
