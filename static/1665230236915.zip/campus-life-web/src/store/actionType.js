export const MENU_TOGGLE = 'menuToggle'
