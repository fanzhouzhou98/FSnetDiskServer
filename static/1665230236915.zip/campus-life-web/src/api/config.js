// 考虑到网站可能有好几个域名，所以单独提出来

export const API = 'http://127.0.0.1:7001'

export const URLAPI = 'http://127.0.0.1:7001'
