import UploadView from './Upload.jsx'

export default UploadView
