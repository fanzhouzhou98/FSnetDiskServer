import EditorView from './Editor.jsx'

export default EditorView
