import View404 from './404.jsx'

export default View404
