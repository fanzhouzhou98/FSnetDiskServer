import AnimationView from './Animation.jsx'

export default AnimationView
