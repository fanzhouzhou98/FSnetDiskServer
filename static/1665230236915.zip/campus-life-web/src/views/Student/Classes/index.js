import IconView from './IconView.jsx'

export default IconView
