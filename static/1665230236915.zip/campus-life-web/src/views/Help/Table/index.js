import TableView from './Table.jsx'

export default TableView
