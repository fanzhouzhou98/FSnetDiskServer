import React from 'react'
import { Layout } from 'antd'

const { Footer } = Layout

export default () => <Footer className='footer'>React Admin &copy;2022 Created By fanzhouzhou</Footer>
