// This file is created by egg-ts-helper@1.30.2
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportActivity = require('../../../app/controller/activity');
import ExportDormitory = require('../../../app/controller/dormitory');
import ExportFileUpload = require('../../../app/controller/fileUpload');
import ExportGrade = require('../../../app/controller/grade');
import ExportHome = require('../../../app/controller/home');
import ExportMaintain = require('../../../app/controller/maintain');
import ExportMutual = require('../../../app/controller/mutual');
import ExportStudent = require('../../../app/controller/student');
import ExportUser = require('../../../app/controller/user');

declare module 'egg' {
  interface IController {
    activity: ExportActivity;
    dormitory: ExportDormitory;
    fileUpload: ExportFileUpload;
    grade: ExportGrade;
    home: ExportHome;
    maintain: ExportMaintain;
    mutual: ExportMutual;
    student: ExportStudent;
    user: ExportUser;
  }
}
