// This file is created by egg-ts-helper@1.30.2
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportActivity = require('../../../app/model/activity');
import ExportDormitory = require('../../../app/model/dormitory');
import ExportGrade = require('../../../app/model/grade');
import ExportMaintain = require('../../../app/model/maintain');
import ExportMutual = require('../../../app/model/mutual');
import ExportStudent = require('../../../app/model/student');
import ExportUser = require('../../../app/model/user');
import ExportUserInfo = require('../../../app/model/userInfo');

declare module 'egg' {
  interface IModel {
    Activity: ReturnType<typeof ExportActivity>;
    Dormitory: ReturnType<typeof ExportDormitory>;
    Grade: ReturnType<typeof ExportGrade>;
    Maintain: ReturnType<typeof ExportMaintain>;
    Mutual: ReturnType<typeof ExportMutual>;
    Student: ReturnType<typeof ExportStudent>;
    User: ReturnType<typeof ExportUser>;
    UserInfo: ReturnType<typeof ExportUserInfo>;
  }
}
