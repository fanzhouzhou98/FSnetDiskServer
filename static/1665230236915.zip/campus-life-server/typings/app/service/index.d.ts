// This file is created by egg-ts-helper@1.30.2
// Do not modify this file!!!!!!!!!

import 'egg';
type AnyClass = new (...args: any[]) => any;
type AnyFunc<T = any> = (...args: any[]) => T;
type CanExportFunc = AnyFunc<Promise<any>> | AnyFunc<IterableIterator<any>>;
type AutoInstanceType<T, U = T extends CanExportFunc ? T : T extends AnyFunc ? ReturnType<T> : T> = U extends AnyClass ? InstanceType<U> : U;
import ExportActivity = require('../../../app/service/activity');
import ExportDormitory = require('../../../app/service/dormitory');
import ExportGrade = require('../../../app/service/grade');
import ExportLogin = require('../../../app/service/login');
import ExportMaintain = require('../../../app/service/maintain');
import ExportMutual = require('../../../app/service/mutual');
import ExportStudent = require('../../../app/service/student');
import ExportUser = require('../../../app/service/user');

declare module 'egg' {
  interface IService {
    activity: AutoInstanceType<typeof ExportActivity>;
    dormitory: AutoInstanceType<typeof ExportDormitory>;
    grade: AutoInstanceType<typeof ExportGrade>;
    login: AutoInstanceType<typeof ExportLogin>;
    maintain: AutoInstanceType<typeof ExportMaintain>;
    mutual: AutoInstanceType<typeof ExportMutual>;
    student: AutoInstanceType<typeof ExportStudent>;
    user: AutoInstanceType<typeof ExportUser>;
  }
}
